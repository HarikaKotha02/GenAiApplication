package com.vm.GenAiii.FNOLServices;

import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class FNOLServicesImpl implements FNOLServices {

    private final List<FNOL> fnolList = new ArrayList<>(); // Declare and initialize fnolList

    @Override
    public FNOL createFNOL(FNOL fnol) {
        fnolList.add(fnol);
        return fnol;
    }

    @Override
    public FNOL updateFNOL(Long id, FNOL fnol) {
        deleteFNOL(id);
        fnolList.add(fnol);
        return fnol;
    }

    @Override
    public void deleteFNOL(Long id) {
        fnolList.removeIf(fnol -> fnol.getId().equals(id));
    }

    @Override
    public FNOL getFNOLById(Long id) {
        return fnolList.stream()
                .filter(fnol -> fnol.getId().equals(id))
                .findFirst()
                .orElse(null);
    }

    @Override
    public List<FNOL> getAllFNOLs() {
        return new ArrayList<>(fnolList); // Return a copy of the list
    }
}