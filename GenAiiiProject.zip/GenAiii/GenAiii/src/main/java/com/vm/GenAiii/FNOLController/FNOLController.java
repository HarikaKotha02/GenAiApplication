package com.vm.GenAiii.FNOLController;

import com.vm.GenAiii.FNOLServices.FNOLServices; // Import the FNOLServices interface
import com.vm.GenAiii.FNOLServices.FNOL; // Import the FNOL class
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/fnol")
public class FNOLController {

    @Autowired
    private FNOLServices fnolServices;

    @PostMapping
    public ResponseEntity<FNOL> createFNOL(@RequestBody FNOL fnol) {
        FNOL createdFNOL = fnolServices.createFNOL(fnol);
        return ResponseEntity.ok(createdFNOL);
    }

    @GetMapping
    public ResponseEntity<List<FNOL>> getAllFNOLs() {
        List<FNOL> fnols = fnolServices.getAllFNOLs();
        return ResponseEntity.ok(fnols);
    }

    @GetMapping("/{id}")
    public ResponseEntity<FNOL> getFNOLById(@PathVariable Long id) {
        FNOL fnol = fnolServices.getFNOLById(id);
        return ResponseEntity.ok(fnol);
    }

    @PutMapping("/{id}")
    public ResponseEntity<FNOL> updateFNOL(@PathVariable Long id, @RequestBody FNOL fnol) {
        FNOL updatedFNOL = fnolServices.updateFNOL(id, fnol);
        return ResponseEntity.ok(updatedFNOL);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteFNOL(@PathVariable Long id) {
        fnolServices.deleteFNOL(id);
        return ResponseEntity.noContent().build();
    }
    @GetMapping("/hello")
    public String sayHello() {
        return "Hello, World!";
    }
}