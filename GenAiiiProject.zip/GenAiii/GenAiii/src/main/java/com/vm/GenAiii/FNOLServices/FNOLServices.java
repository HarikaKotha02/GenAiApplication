package com.vm.GenAiii.FNOLServices;

import java.util.List;

public interface FNOLServices {
    FNOL createFNOL(FNOL fnol);
    List<FNOL> getAllFNOLs();
    FNOL getFNOLById(Long id);
    FNOL updateFNOL(Long id, FNOL fnol);
    void deleteFNOL(Long id);
}