package com.vm.GenAiii.Model;

import jakarta.validation.constraints.Past;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import jakarta.validation.Constraint;
import jakarta.validation.Payload;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.time.LocalDate;

public class FNOL {

    @Pattern(regexp = "^[A-Za-z]\\d{7}$", message = "Policy number must start with an alphabet followed by 7 digits")
    private String policyNumber;

    @Past(message = "Policy start date must be a past date")
    private LocalDate policyStartDate;

    @PolicyDateConstraint(message = "Policy end date must be greater than or equal to policy start date")
    private LocalDate policyEndDate;

    // Getters and Setters
    public String getPolicyNumber() {
        return policyNumber;
    }

    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }

    public LocalDate getPolicyStartDate() {
        return policyStartDate;
    }

    public void setPolicyStartDate(LocalDate policyStartDate) {
        this.policyStartDate = policyStartDate;
    }

    public LocalDate getPolicyEndDate() {
        return policyEndDate;
    }

    public void setPolicyEndDate(LocalDate policyEndDate) {
        this.policyEndDate = policyEndDate;
    }

    // Custom Annotation
    @Constraint(validatedBy = PolicyDateValidator.class)
    @Target({ElementType.FIELD, ElementType.METHOD})
    @Retention(RetentionPolicy.RUNTIME)
    public @interface PolicyDateConstraint {
        String message() default "Invalid policy end date";
        Class<?>[] groups() default {};
        Class<? extends Payload>[] payload() default {};
    }

    // Validator Class
    public static class PolicyDateValidator implements ConstraintValidator<PolicyDateConstraint, LocalDate> {

        @Override
        public boolean isValid(LocalDate policyEndDate, ConstraintValidatorContext context) {
            if (policyEndDate == null) {
                return true; // Null values are handled by @NotNull if required
            }
            // Access policyStartDate from the enclosing FNOL class
            FNOL fnol = (FNOL) context.unwrap(FNOL.class);
            LocalDate policyStartDate = fnol.getPolicyStartDate();
            return policyStartDate != null && !policyEndDate.isBefore(policyStartDate);
        }
    }
}